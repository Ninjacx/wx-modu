App({
  onLaunch: function () { // wx.setStorageSync('userInfo')
    this.globalData.userInfo = wx.getStorageSync('userInfo') || ''
  },
  globalData: {
    userInfo: "",
  }
})
